If you want me to put your config write me on discord 53d#8951
